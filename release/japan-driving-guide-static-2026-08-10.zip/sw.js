const CACHE_NAME = "japan-driving-guide-7a07f24319fdf999";
const BASE_PATH = "/";
const OFFLINE_URL = "/offline.html";
const PRECACHE_URLS = [
  "/_astro/LearningShell.LopZt75Q.css",
  "/_astro/SignalLessonPage.astro_astro_type_script_index_0_lang.Cg0TQR8P.js",
  "/assets/app-icon.svg",
  "/assets/official/mlit-signs/railway-crossing-a.gif",
  "/assets/official/npa-signs/npa-maximum-speed-50.jpg",
  "/assets/official/npa-signs/npa-no-entry.jpg",
  "/assets/official/npa-signs/npa-no-parking.png",
  "/assets/official/npa-signs/npa-no-stopping-or-parking.png",
  "/assets/official/npa-signs/npa-no-u-turn.png",
  "/assets/official/npa-signs/npa-one-way-straight.png",
  "/assets/official/npa-signs/npa-pedestrian-crossing.jpg",
  "/assets/official/npa-signs/npa-slow-bilingual.jpg",
  "/assets/official/npa-signs/npa-stop-bilingual.jpg",
  "/data/quiz-bank.json",
  "/diagrams/D002.svg",
  "/en/fast-track/",
  "/en/",
  "/en/learn/cyclists/",
  "/en/learn/eligibility/",
  "/en/learn/emergency/",
  "/en/learn/expressways/",
  "/en/learn/fuel/",
  "/en/learn/",
  "/en/learn/intersections/",
  "/en/learn/left-side-driving/",
  "/en/learn/parking/",
  "/en/learn/pedestrians/",
  "/en/learn/rail-crossings/",
  "/en/learn/safety-basics/",
  "/en/learn/signals/",
  "/en/learn/signs/",
  "/en/learn/speed/",
  "/en/learn/stop-signs/",
  "/en/learn/weather/",
  "/en/sources/",
  "/",
  "/manifest.webmanifest",
  "/offline.html",
  "/zh-TW/fast-track/",
  "/zh-TW/",
  "/zh-TW/learn/cyclists/",
  "/zh-TW/learn/eligibility/",
  "/zh-TW/learn/emergency/",
  "/zh-TW/learn/expressways/",
  "/zh-TW/learn/fuel/",
  "/zh-TW/learn/",
  "/zh-TW/learn/intersections/",
  "/zh-TW/learn/left-side-driving/",
  "/zh-TW/learn/parking/",
  "/zh-TW/learn/pedestrians/",
  "/zh-TW/learn/rail-crossings/",
  "/zh-TW/learn/safety-basics/",
  "/zh-TW/learn/signals/",
  "/zh-TW/learn/signs/",
  "/zh-TW/learn/speed/",
  "/zh-TW/learn/stop-signs/",
  "/zh-TW/learn/weather/",
  "/zh-TW/sources/"
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(PRECACHE_URLS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith("japan-driving-guide-") && key !== CACHE_NAME).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin || !url.pathname.startsWith(BASE_PATH)) return;

  if (request.mode === "navigate") {
    event.respondWith(fetch(request).then((response) => {
      if (response.ok) caches.open(CACHE_NAME).then((cache) => cache.put(request, response.clone()));
      return response;
    }).catch(async () => (await caches.match(request)) || (await caches.match(OFFLINE_URL))));
    return;
  }

  event.respondWith(caches.match(request).then((cached) => cached || fetch(request).then((response) => {
    if (response.ok) caches.open(CACHE_NAME).then((cache) => cache.put(request, response.clone()));
    return response;
  })));
});
